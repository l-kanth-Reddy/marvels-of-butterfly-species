import os
import shutil
import pandas as pd # type: ignore
from sklearn.model_selection import train_test_split # type: ignore

# Load CSV
csv_path = "butterflies/Butterfly Identification/Training_set.csv"
images_path = "butterflies/Butterfly Identification/train/"
output_path = "butterflies/Butterfly Identification/dataset/"

df = pd.read_csv(csv_path)

# Split into train and val sets (80-20)
train_df, val_df = train_test_split(df, test_size=0.2, stratify=df['label'], random_state=42)

# Function to copy images to target folder
def copy_images(df, split):
    for _, row in df.iterrows():
        filename = row['filename']
        label = row['label']

        src = os.path.join(images_path, filename)
        dst_dir = os.path.join(output_path, split, label)
        dst = os.path.join(dst_dir, filename)

        os.makedirs(dst_dir, exist_ok=True)
        if os.path.exists(src):  # only copy if file exists
            shutil.copy(src, dst)
        else:
            print(f"⚠️ File not found: {src}")

# Copy training and validation images
copy_images(train_df, "train")
copy_images(val_df, "val")

print("✅ Dataset organized into class folders!")
